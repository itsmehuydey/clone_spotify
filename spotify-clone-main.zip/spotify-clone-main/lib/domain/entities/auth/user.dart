class UserEntity {

  String ? fullName;
  String ? email;
  String ? imageURL;

  UserEntity({
    this.fullName,
    this.email,
    this.imageURL
  });
}